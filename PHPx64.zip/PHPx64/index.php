<?php

ini_set("display_errors","Off");

ob_start("ob_gzhandler");

function extension($fn) {
	return (strpos($fn, '.') ? strtolower(substr(strrchr($fn, '.'), 1)) : '');
}

function find_icon($file) {

		$image_path = "http://www.fusionxlan.com/images/index_icons/winxp/";
		$ext = extension($file);

		if ($ext == '')
		{
			return $image_path ."generic.png";
		}
		$icon_types = array(
		'binary' => array('bat', 'bin', 'com', 'dmg', 'dms', 'exe', 'msi',
			'msp', 'pif', 'pyd', 'scr', 'so'),
		'binhex' => array('hqx'),
		'cd' => array('bwi', 'bws', 'bwt', 'ccd', 'cdi', 'cue', 'img',
			'iso', 'mdf', 'mds', 'nrg', 'nri', 'sub', 'vcd'),
		'comp' => array('cfg', 'conf', 'inf', 'ini', 'log', 'nfo', 'reg'),
		'compressed' => array('7z', 'a', 'ace', 'ain', 'alz', 'amg', 'arc',
			'ari', 'arj', 'bh', 'bz', 'bz2', 'cab', 'deb', 'dz', 'gz',
			'io', 'ish', 'lha', 'lzh', 'lzs', 'lzw', 'lzx', 'msx', 'pak',
			'rar', 'rpm', 'sar', 'sea', 'sit', 'taz', 'tbz', 'tbz2',
			'tgz', 'tz', 'tzb', 'uc2', 'xxe', 'yz', 'z', 'zip', 'zoo'),
		'dll' => array('386', 'db', 'dll', 'ocx', 'sdb', 'vxd'),
		'doc' => array('abw', 'ans', 'chm', 'cwk', 'dif', 'doc', 'dot',
			'mcw', 'msw', 'pdb', 'psw', 'rtf', 'rtx', 'sdw', 'stw', 'sxw',
			'vor', 'wk4', 'wkb', 'wpd', 'wps', 'wpw', 'wri', 'wsd'),
		'image' => array('adc', 'art', 'bmp', 'cgm', 'dib', 'gif', 'ico',
			'ief', 'jfif', 'jif', 'jp2', 'jpc', 'jpe', 'jpeg', 'jpg', 'jpx',
			'mng', 'pcx', 'png', 'psd', 'psp', 'swc', 'sxd', 'tga',
			'tif', 'tiff', 'wmf', 'wpg', 'xcf', 'xif', 'yuv'),
		'java' => array('class', 'jar', 'jav', 'java', 'jtk'),
		'js' => array('ebs', 'js', 'jse', 'vbe', 'vbs', 'wsc', 'wsf',
			'wsh'),
		'key' => array('aex', 'asc', 'gpg', 'key', 'pgp', 'ppk'),
		'mov' => array('amc', 'dv', 'm4v', 'mac', 'mov', 'mp4v', 'mpg4',
			'pct', 'pic', 'pict', 'pnt', 'pntg', 'qpx', 'qt', 'qti',
			'qtif', 'qtl', 'qtp', 'qts', 'qtx'),
		'movie' => array('asf', 'asx', 'avi', 'div', 'divx', 'dvi', 'm1v',
			'm2v', 'mkv', 'movie', 'mp2v', 'mpa', 'mpe', 'mpeg', 'mpg',
			'mps', 'mpv', 'mpv2', 'ogm', 'ram', 'rmvb', 'rnx', 'rp', 'rv',
			'vivo', 'vob', 'wmv', 'xvid'),
		'pdf' => array('edn', 'fdf', 'pdf', 'pdp', 'pdx'),
		'php' => array('inc', 'php', 'php3', 'php4', 'php5', 'phps',
			'phtml'),
		'ppt' => array('emf', 'pot', 'ppa', 'pps', 'ppt', 'sda', 'sdd',
			'shw', 'sti', 'sxi'),
		'ps' => array('ai', 'eps', 'ps'),
		'sound' => array('aac', 'ac3', 'aif', 'aifc', 'aiff', 'ape', 'apl',
			'au', 'ay', 'bonk', 'cda', 'cdda', 'cpc', 'fla', 'flac',
			'gbs', 'gym', 'hes', 'iff', 'it', 'itz', 'kar', 'kss', 'la',
			'lpac', 'lqt', 'm4a', 'm4p', 'mdz', 'mid', 'midi', 'mka',
			'mo3', 'mod', 'mp+', 'mp1', 'mp2', 'mp3', 'mp4', 'mpc',
			'mpga', 'mpm', 'mpp', 'nsf', 'oda', 'ofr', 'ogg', 'pac', 'pce',
			'pcm', 'psf', 'psf2', 'ra', 'rm', 'rmi', 'rmjb', 'rmm', 'sb',
			'shn', 'sid', 'snd', 'spc', 'spx', 'svx', 'tfm', 'tfmx',
			'voc', 'vox', 'vqf', 'wav', 'wave', 'wma', 'wv', 'wvx', 'xa',
			'xm', 'xmz'),
		'tar' => array('gtar', 'tar'),
		'text' => array('asm', 'c', 'cc', 'cp', 'cpp', 'cxx', 'diff', 'h',
			'hpp', 'hxx', 'm3u', 'md5', 'patch', 'pls', 'py', 'sfv', 'sh',
			'txt'),
		'uu' => array('uu', 'uud', 'uue'),
		'web' => array('asa', 'asp', 'aspx', 'cfm', 'cgi', 'css', 'dhtml',
			'dtd', 'grxml', 'htc', 'htm', 'html', 'htt', 'htx', 'jsp', 'lnk',
			'mathml', 'mht', 'mhtml', 'perl', 'pl', 'plg', 'rss', 'shtm',
			'shtml', 'stm', 'swf', 'tpl', 'wbxml', 'xht', 'xhtml', 'xml',
			'xsl', 'xslt', 'xul'),
		'xls' => array('csv', 'dbf', 'prn', 'pxl', 'sdc', 'slk', 'stc', 'sxc',
			'xla', 'xlb', 'xlc', 'xld', 'xlr', 'xls', 'xlt', 'xlw'));
		foreach ($icon_types as $png_name => $exts)
		{
			if (in_array($ext, $exts))
			{
				return $image_path .$png_name .".png";
			}
		}
		return $image_path ."unknown.png";
}

function size_hum_read($size) {

	$i=0;
	$iec = array("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB");
	while (($size/1024)>1) {
		$size=$size/1024;
		$i++;
	}

	$size = number_format($size,2,".",",");
	return $size ." ". $iec[$i];
}


function time_hum_read($file) {

	$time = filemtime($file);
	
	return date("d-M-Y h:i a", $time);
}



function dirlisting($path) {

	$url = "http://www.fusionxlan.com/PHPx64/";
	$directories= "";
	$files = "";
	$blocked = array(".htaccess","index.php","style.css","php.gif","zend2.gif");

	$handle = opendir($path);

	echo "<table border=\"0\" width=\"90%\" cellpadding=\"2\" cellspacing=\"0\">";
	echo "\n<tr><td colspan=\"4\"><table border=\"0\" width=\"100%\" cellpadding=\"0\"><tr><td width=\"50%\"><span class=\"hd3\">Index of <a href=\"{$url}\" style=\"font-size:18px\">/PHPx64</a></b></span></td></tr></table></td></tr>";
	echo "\n<tr><td width=\"17\">&nbsp;</td><td><b>Name</b></td><td align=\"right\"><b>Size</b></td><td align=\"right\"><b>Last Modified</b></td></tr>";

	while ($a = readdir($handle)) {
		if(!preg_match('/^\./',$a)){
			$full_path = "{$path}/{$a}";
			if(!in_array($a,$blocked) && !is_dir($full_path)){
				$files_array[] = $a;
			} elseif(!in_array($a,$blocked))  {
				$directories_array = $a;
			}
		}
	}

	closedir($handle);


	natcasesort($directories_array);
	natcasesort($files_array);

	$row_colors = array("#E2E2E2", "#FFFFFF");
	$i = 0;

	foreach ($directories_array as $dir) {
		$row_color = $row_colors[($i % 2)];
		echo "\n<tr bgcolor=\"{$row_color}\"><td><img src=\"http://www.fusionxlan.com/images/index_icons/winxp/dir.png\"></td><td>{$dir}</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
		$i++;
	}

	foreach ($files_array as $file) {
		$row_color = $row_colors[($i % 2)];
		echo "\n<tr bgcolor=\"{$row_color}\"><td><a href=\"{$url}{$file}\"><img src=\"". find_icon($file) ."\" border=\"0\"></a></td><td><a href=\"{$url}{$file}\">{$file}</a></td><td align=\"right\">". size_hum_read(filesize($path."/".$file)) ."</td><td align=\"right\">". time_hum_read($path."/".$file) ."</td></tr>";
		$i++;
	}

	echo "\n<tr><td colspan=\"4\"><table border=\"0\" width=\"100%\" cellpadding=\"0\"><tr><td width=\"50%\"><br />". $_SERVER["SERVER_SIGNATURE"] ."</td><td align=\"right\" width=\"50%\"><br />". date("F jS, Y @ g:i A") ."</td></tr></table></td></tr>";
	echo "\n<tr><td colspan=\"4\"><br><a href=\"http://www.fusionxlan.com/rss.php?php\" target=\"_blank\"><img src=\"http://www.fusionxlan.com/images/rss16.gif\" alt=\"RSS\" border=\"0\" /> PHP x64 Project RSS</a></td></tr>";
	echo "</table>";

	return 1;
}




?>
<html>
<head>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<META NAME="Robots" CONTENT="index,follow">
<META NAME="Keywords" CONTENT="fusion-x lan,fxl forum,fusionx,lan party,lan,party,lanparty,bawls,games,gaming,computer gaming,counter-strike,battlefield,red faction,halo,kansas city, missouri">
<META NAME="Description" CONTENT="Fusion-X LAN is a LAN Party in the Kansas City, Missouri & Kansas City, Kansas Area. If you're hungry for some great gaming, check us out.">

<!-- no cache headers -->

 <meta http-equiv="Pragma" content="no-cache">
 <meta http-equiv="Expires" content="-1">
 <meta http-equiv="Cache-Control" content="no-cache">
<!-- end no cache headers -->

<!-- style sheet -->
 <link rel="stylesheet" href="style.css">
<!-- end style sheet -->

<title>fusion-x lan - the PHP x64 Project</title>

</head>
<body>
<center>
<table border="0" width="90%" cellpadding="2" cellspacing="0">
  <tr>
    <td><span style="font-size:14pt;color:#000080"><b>The PHP 5.2.1 x64 Project</b></span></td>
  </tr>
  <tr>
    <td><br />
    If you would like to contribute to the project with code or testing, feel free to at our <a href="http://www.fusionxlan.com/forum/index.php?showforum=23" target="_blank">PHPx64 Forum</a>.<br />
    If you would like to make a monetary donation to help cover costs of the PHPx64 development please use the buttons below.<br />
    <table border="0" width="100%">
      <tr>
        <td align="center"><b>$2 USD</b></td>
        <td align="center"><b>$5 USD</b></td>
        <td align="center"><b>Custom Amount</b></td>
      </tr>
      <tr>
        <td align="center"><form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	<input type="hidden" name="cmd" value="_s-xclick">
	<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but21.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
	<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHVwYJKoZIhvcNAQcEoIIHSDCCB0QCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBYJljmotsI8w5rBuvHbTBW6kFxbB2/RmqDZiJe4J6ouC2czJUZ+6i8A7csZl8B83c7Cv5vb11E+s8htvt+VHsejMw0xJUOoedPUKZ96wgN0XndsHVZPMYPO21C8dXI74mGjTLd/iA4WavnXyP+ZUJMRSaTCJWBYtHpj+v2Ots2jTELMAkGBSsOAwIaBQAwgdQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQINgyrhNaR3S6AgbB0oVNGXFYAPh4hd88Qa4E4bC0PXF+YZwFrIrqU2KbCyuOA/CJUQmF40NolR9sQA5SbokP88nuevaguVwAHzB3CogqctbQIFeQO6KWSKNBrM4VoZV71nKCwKPrgH0VM7yONtsKT9R/SF9Xa6ztYuaZlHV/infXDdiqW7LujVS2trnhxwSpY2NWyV421BcFe3NXeZlc8L+wfCkIZ2LE+bpCNOivXcquUlIj9DT8pBAkV2KCCA4cwggODMIIC7KADAgECAgEAMA0GCSqGSIb3DQEBBQUAMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTAeFw0wNDAyMTMxMDEzMTVaFw0zNTAyMTMxMDEzMTVaMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAwUdO3fxEzEtcnI7ZKZL412XvZPugoni7i7D7prCe0AtaHTc97CYgm7NsAtJyxNLixmhLV8pyIEaiHXWAh8fPKW+R017+EmXrr9EaquPmsVvTywAAE1PMNOKqo2kl4Gxiz9zZqIajOm1fZGWcGS0f5JQ2kBqNbvbg2/Za+GJ/qwUCAwEAAaOB7jCB6zAdBgNVHQ4EFgQUlp98u8ZvF71ZP1LXChvsENZklGswgbsGA1UdIwSBszCBsIAUlp98u8ZvF71ZP1LXChvsENZklGuhgZSkgZEwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tggEAMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAgV86VpqAWuXvX6Oro4qJ1tYVIT5DgWpE692Ag422H7yRIr/9j/iKG4Thia/Oflx4TdL+IFJBAyPK9v6zZNZtBgPBynXb048hsP16l2vi0k5Q2JKiPDsEfBhGI+HnxLXEaUWAcVfCsQFvd2A1sxRr67ip5y2wwBelUecP3AjJ+YcxggGaMIIBlgIBATCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTA3MDQxNjAyNTQyMlowIwYJKoZIhvcNAQkEMRYEFJ7r4lTPLu4Xp7wxHExJIGT79jfBMA0GCSqGSIb3DQEBAQUABIGAiGkbGOOAOfiLyRp1S+azpPr1vTuK9zEisOKJEIIc5IaSxWklOPAtzBcTPv0Q66k9+qAJSJETXPbGtNYVG+yHq75tCPQ55KwSTc0XlbDJPIc4bqLZUzN1GjGokCegl5HacbsEUBcHRdcLVKDOs+rfQWoAd2Xcn8fcYa/sm0tL6z8=-----END PKCS7-----
"></form></td>
        <td align="center"><form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	<input type="hidden" name="cmd" value="_s-xclick">
	<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but21.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
	<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHVwYJKoZIhvcNAQcEoIIHSDCCB0QCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBAnqHvju/g6eClWmSl+JGBgwwZ7ZNS60Kq4TCOCFa1zYlnZ1HSTyxQunWvxWbIVZulp2tC4Foiimk3wrBPc+1J0D2uWEqOhubL91s5kBBI8sMeKaIk7r68v2EIRle4TIoAmuDAj1SNGpMWdiQrauLwZGFXKOiUyZkOVRr8Vv4pjzELMAkGBSsOAwIaBQAwgdQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIzNClytrJb1GAgbCEco1u9sGcdCl3rnHlMXc0QmnlNzF7LMIIUDPjIrDPYBY3B8KifD3kvpnTKy+2/8+NuNDeyfBm4YGcN2u2wcif65anenxkmkt9cGGDfZa65qWA1fC6Y5nZzyIZAFPgZVTiHYE4H+SN4TQI2g8L1+YjSVu6lRIGuXPD4OG0mZcQslj6olfkHsVfObmn3+AWOIBFz5Zl8x7pzNvg1lqXQN2CqoPGvbygmLiE4qH8mwHt5KCCA4cwggODMIIC7KADAgECAgEAMA0GCSqGSIb3DQEBBQUAMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTAeFw0wNDAyMTMxMDEzMTVaFw0zNTAyMTMxMDEzMTVaMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAwUdO3fxEzEtcnI7ZKZL412XvZPugoni7i7D7prCe0AtaHTc97CYgm7NsAtJyxNLixmhLV8pyIEaiHXWAh8fPKW+R017+EmXrr9EaquPmsVvTywAAE1PMNOKqo2kl4Gxiz9zZqIajOm1fZGWcGS0f5JQ2kBqNbvbg2/Za+GJ/qwUCAwEAAaOB7jCB6zAdBgNVHQ4EFgQUlp98u8ZvF71ZP1LXChvsENZklGswgbsGA1UdIwSBszCBsIAUlp98u8ZvF71ZP1LXChvsENZklGuhgZSkgZEwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tggEAMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAgV86VpqAWuXvX6Oro4qJ1tYVIT5DgWpE692Ag422H7yRIr/9j/iKG4Thia/Oflx4TdL+IFJBAyPK9v6zZNZtBgPBynXb048hsP16l2vi0k5Q2JKiPDsEfBhGI+HnxLXEaUWAcVfCsQFvd2A1sxRr67ip5y2wwBelUecP3AjJ+YcxggGaMIIBlgIBATCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTA3MDQxNjAyNTczM1owIwYJKoZIhvcNAQkEMRYEFPCNguEOwwed+h0Uu81iHYy5zAcSMA0GCSqGSIb3DQEBAQUABIGAlwEnGtlWax8SUy61xTt0l8GPfLp6yePwGKlx7ZyG3yWD8hJoxCnhnaHl/cFce8InOdn3D1Z9IVqlieii/63r24aem0pWKGFJh1+wPwkhv1sFhZNETCPvEWBtSfnBDp3zqMz+8othRXC9yyRUdLNfOYLFIzLAxBtCR5SWp04dtc4=-----END PKCS7-----
">
</form></td>
        <td align="center"><form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	<input type="hidden" name="cmd" value="_s-xclick">
	<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but21.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
	<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHTwYJKoZIhvcNAQcEoIIHQDCCBzwCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYAmTKEbdu84qaQp9ZtfZfo2tN/hz33TzIMKCwroTIriBqvHYL9kAOJAbxcPp4848uh49Wyt8aN0pjZTQGPXW1PSdwp5xrNKnrHycHvpSXDGD/7I7moQxPKWvm23HHFDL3wyTSeo7qfH3ApDgHGqYc6irvu2f072ZtbuTjQoOaslEzELMAkGBSsOAwIaBQAwgcwGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIbOXyvJA65aCAgajf2BAjVtip30rMurwTPmQITm1x4/YLmTBGs6QSCnctGbVKc7ZzAc/Cy0SH0W7lwaQEsFyA/ZdkEdQuqO05o7qpmPnfXrvcxanbRuppnny+JALAOy3X9n4wb7aAAmE8XISQ/JY4xe1OtNpLwCR/tqz6BSeEvkeStfw8riBpclo7NugrVWvnyE+Q/FG5UlG+G1B/0K6lrDvtQMx+2842YSechpCnIyqDmVGgggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wNzA0MTYwMjU5MjNaMCMGCSqGSIb3DQEJBDEWBBRBIe6RSpVSqf7EHG0MeS2nSxEnsDANBgkqhkiG9w0BAQEFAASBgD9VuPJacetRe/Hjf11BPsjNVv96Hlp06C1OES7M9TO9V0dVMoifnaNzqqC5OjjeGIGV2pxCjBIRLeosT4KnU5o15vbRZE8QDckeGiUM2Z/Vb9OdZrnpV8W8xObJs3RezR/v4er/8Y4t2TF6tl1hRIRstxaW/+lAZorU1fwgjntj-----END PKCS7-----
">
</form></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<?php
dirlisting("/home/content/c/h/r/chriskristen/html/fxl/PHPx64");

?>
</center>
</body>
</html>
