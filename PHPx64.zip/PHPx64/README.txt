##############################################################

 PHP 5.2.5 x64 - 2007-11-12 snapshot

 compiled by PaRK_7677
 email: park@fusionxlan.com

 USE ONLY WITH 64-BIT HTTP SERVERS!
  IIS 6.0 (x64)
  Apache 2.x (x64)


 http://www.fusionxlan.com/PHPx64.php


 visit http://www.fusionxlan.com/forum/index.php?showforum=23
 to help with the ongoing PHP x64 development! Thank you!

###############################################################


 Configure Command:

 cscript /nologo configure.js "--enable-snapshot-build" "--enable-mysqlnd"


This version includes no guarantee it works. Provided "AS-IS". There are
bugs, I know. Mainly with file functions "resetting" the connection if
an error occurs. If you know or have an idea how to fix this, please join
the effort! Even though it was built with "--enable-snapshot-build"
extensions were manually taken out due to not being ready. 


Easy installation:
----------------------------------------------------------------

Read "install.txt" included in the ZIP.


RE: MS SQL Extension
----------------------------------------------------------------
Microsoft has discontinued the library necessary to build php_mssql.dll extension.
It is impossible to get a 64-bit library required to build a 64-bit extension.

Work Around: Use ODBTP Extension (php_odbtp.dll / php_odbtp_mssql.dll)

Location: (Archive)\MS SQL Alternative\

Follow instructions located inside.

!!!! OR !!!!

Use php_dblib.dll extension and follow directions here:
http://docs.moodle.org/en/Installing_MSSQL_for_PHP#Using_FreeTDS_on_Windows


